# Yolov8 > 2024-04-06 6:39am
https://universe.roboflow.com/hamza-bhai/yolov8-pqndz

Provided by a Roboflow user
License: CC BY 4.0

